#!/bin/bash
rm -rf CMakeFiles
rm cmake_install.cmake
rm CMakeCache.txt
