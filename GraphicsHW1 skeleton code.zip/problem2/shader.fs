#version 330 core
// declare input and output

void main()
{
    // fill in
    
}