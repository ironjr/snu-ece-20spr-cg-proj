#version 330 core
out vec4 FragColor;
// declare an uniform variable

void main()
{
    // Fill in the blank
}
